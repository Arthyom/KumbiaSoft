# LICENSE #

### Theme License ###

Looper is designed, developed and supported by Stilearning.

Use of this theme is governed by the license terms of the Bootstrap Themes platform (https://themes.getbootstrap.com/licenses/)


### Questions? ###

Don't hesitate to hit us up with questions – bent10@stilearning.com.
