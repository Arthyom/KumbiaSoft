<?php
    
    class UsuariosController extends ScaffoldController{	
        public $model = 'usuarios';
    }