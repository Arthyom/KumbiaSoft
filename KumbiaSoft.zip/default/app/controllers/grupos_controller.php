<?php
    
    class GruposController extends ScaffoldController{	
        public $model = 'grupos';
    }