<?php
    
    class MenusController extends ScaffoldController{	
    
        public $model = 'menus';
    }