<?php

class TablesController extends AppController
{

    public function index()
    {

    }

    public function table_basic()
    {
        //View::template("layouts/default");
    }

    public function table_datatables()
    {

    }
    public function table_responsive_datatables()
    {

    }
    public function table_filters_datatables()
    {

    }
}





 