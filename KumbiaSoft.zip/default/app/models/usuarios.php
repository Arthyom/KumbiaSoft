<?php
    
    class usuarios extends ActiveRecord{	
    
    }