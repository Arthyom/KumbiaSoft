<?php
    
    class grupos extends ActiveRecord{	
    
    }