
<?php
    
    class menus extends ActiveRecord{	
    
    }