#To Do List
* Remove deprected code
* Add namespaces
* Rename file with camelCase notation
